"""
Prediksi Permintaan Harian Minion Mart
Proyek Penambangan Data - Teknik Informatika UMRAH

Prediksi : rata-rata bergerak 21 hari (36 produk, data 1 Agustus - 30 September 2026)
Klaster  : K-Means (k=3) fast/medium/slow-moving untuk semua produk (klaster.csv)

Cara menjalankan:
    pip install -r requirements.txt
    python -m streamlit run app.py

Susunan halaman (dari yang terpenting ke yang paling rinci):
    1. Jawaban utama   : saran stok, angka paling besar di halaman
    2. Bukti pendukung : grafik penjualan + perkiraan, dua angka pendamping
    3. Rincian         : cara hitung dan tabel per hari
"""

import math
from datetime import timedelta
from html import escape
from pathlib import Path

import altair as alt
import pandas as pd
import streamlit as st

# ---------------- pengaturan ----------------
JENDELA = 21
PILIHAN_HARI = [1, 3, 7, 14]
TINGKAT_AMAN = {"90%": 1.28, "95%": 1.64}
NAMA_HARI = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
NAMA_BULAN = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"]
URUTAN_KLASTER = ["Fast-moving", "Medium-moving", "Slow-moving"]
TAMPIL = {"Fast-moving": "Laris", "Medium-moving": "Sedang", "Slow-moving": "Kurang laku"}
GAYA_KLASTER = {"Fast-moving": "fast", "Medium-moving": "medium", "Slow-moving": "slow"}
PERAN_KLASTER = {
    "Fast-moving": "Stok diutamakan dan dipantau harian.",
    "Medium-moving": "Restock berkala sesuai kebutuhan.",
    "Slow-moving": "Stok secukupnya agar tidak menumpuk.",
}

# Warna: biru denim (utama), kuning minion (aksen, hanya untuk angka utama), abu (pendukung)
NAVY, BIRU, BIRU_MUDA, ABU, ABU_TUA = "#14213D", "#1F4E8C", "#6F9BD6", "#B4BDCB", "#5B6778"
WARNA_KLASTER = [BIRU, BIRU_MUDA, ABU]
FONT = "Plus Jakarta Sans, system-ui, sans-serif"


FOLDER = Path(__file__).parent  # file CSV dibaca relatif ke app.py, bukan ke folder kerja


# ---------------- perhitungan ----------------
@st.cache_data
def muat_data():
    penjualan = pd.read_csv(FOLDER / "data_penjualan.csv", parse_dates=["tanggal"], dtype={"produk": str})
    produk = pd.read_csv(FOLDER / "produk.csv", dtype={"produk": str}).set_index("produk")
    penjualan = penjualan.sort_values(["produk", "tanggal"])
    riwayat = {n: g["jumlah_terjual"].tolist() for n, g in penjualan.groupby("produk")}
    return riwayat, produk, penjualan["tanggal"].max()


@st.cache_data
def muat_klaster():
    return pd.read_csv(FOLDER / "klaster.csv", dtype={"produk": str, "klaster": str})


def prediksi_ke_depan(riwayat, jumlah_hari):
    """Tiap hari = rata-rata JENDELA hari terakhir; hasilnya dipakai untuk hari berikutnya."""
    data, hasil = list(riwayat), []
    for _ in range(jumlah_hari):
        rata2 = sum(data[-JENDELA:]) / min(JENDELA, len(data))
        hasil.append(rata2)
        data.append(rata2)
    return hasil


def saran_stok(prediksi, rmse, z):
    """Saran stok = total prediksi n hari + z * RMSE * akar(n)."""
    n = len(prediksi)
    total = sum(prediksi)
    cadangan = z * rmse * math.sqrt(n)
    return math.ceil(total + cadangan), total, cadangan


# ---------------- format tampilan (angka gaya Indonesia: 1.234,5) ----------------
def angka(x, desimal=1):
    return f"{x:,.{desimal}f}".replace(",", "_").replace(".", ",").replace("_", ".")


def rupiah(x):
    return "Rp" + angka(x, 0)


def tanggal_indo(t):
    return f"{NAMA_HARI[t.weekday()]}, {t.day} {NAMA_BULAN[t.month - 1]} {t.year}"


def tanggal_pendek(t):
    return f"{NAMA_HARI[t.weekday()][:3]}, {t.day} {NAMA_BULAN[t.month - 1]}"


def tulis_html(teks):
    """Tampilkan HTML. Spasi awal dan baris kosong dibuang supaya tidak dianggap kode."""
    bersih = "\n".join(b.strip() for b in teks.splitlines() if b.strip())
    st.markdown(bersih, unsafe_allow_html=True)


def pil(klaster):
    return f'<span class="pil {GAYA_KLASTER.get(klaster, "slow")}">{escape(TAMPIL.get(klaster, str(klaster)))}</span>'


def judul_kartu(judul, keterangan=""):
    return f'<div class="kartu-judul"><h3>{judul}</h3><span>{keterangan}</span></div>'


# ---------------- gaya halaman ----------------
st.set_page_config(page_title="Prediksi Permintaan Minion Mart", page_icon="📊", layout="wide", initial_sidebar_state="expanded")
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

:root {
  --navy: #14213D; --biru: #1F4E8C; --biru-muda: #6F9BD6; --kuning: #FFC72C;
  --redup: #5B6778; --garis: #DCE3EE; --putih: #FFFFFF; --latar: #F3F5F9;
}

/* ===== tipografi: satu keluarga huruf, skala jelas ===== */
html, body, .stApp, .stApp :is(p, label, button, input, textarea, li, td, th, a, h1, h2, h3, h4,
  div[data-baseweb], span:not([data-testid="stIconMaterial"])) {
  font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
}
.stApp { color: var(--navy); }
.stApp :is(h1, h2, h3) { letter-spacing: -0.01em; }

/* ===== kerangka: lebar terbatas, ruang napas di tepi ===== */
.block-container { max-width: 1240px; padding: 2.2rem 2rem 3rem; }
header[data-testid="stHeader"] { background: transparent; }
footer, .stAppDeployButton { display: none !important; }
[data-testid="stSidebar"] { border-right: 1px solid var(--garis); }
[data-testid="stSidebar"] h3 { font-size: 0.95rem !important; font-weight: 700; padding: 0 0 .2rem; }

/* ===== level 0: kepala halaman ===== */
.kepala { display: flex; justify-content: space-between; align-items: flex-end; gap: 16px;
          flex-wrap: wrap; margin-bottom: 6px; }
.kepala h1 { font-size: 1.9rem; font-weight: 800; line-height: 1.15; margin: 0; padding: 0; }
.kepala p { margin: 6px 0 0; color: var(--redup); font-size: 0.95rem; }
.kepala .data { font-size: 0.82rem; color: var(--redup); background: var(--putih);
                border: 1px solid var(--garis); border-radius: 999px; padding: 6px 14px; }

/* ===== panel kiri: menu navigasi rata kiri ===== */
[data-testid="stSidebar"] [data-testid="stSidebarUserContent"] { padding-top: 1.2rem; }
[data-testid="stSidebar"] [class*="st-key-nav_"] { margin-bottom: -6px; }
[data-testid="stSidebar"] [class*="st-key-nav_"] button {
  width: 100%; border: none; border-radius: 8px; background: transparent; box-shadow: none;
  padding: 9px 12px; min-height: 0; justify-content: flex-start !important;
}
[data-testid="stSidebar"] [class*="st-key-nav_"] button > div {
  justify-content: flex-start !important; text-align: left !important; width: 100%; gap: 10px;
}
[data-testid="stSidebar"] [class*="st-key-nav_"] button [data-testid="stMarkdownContainer"] {
  flex: 1 1 auto; text-align: left !important;
}
[data-testid="stSidebar"] [class*="st-key-nav_"] button p {
  font-size: 0.92rem; font-weight: 500; color: #3B4658; text-align: left !important; letter-spacing: 0;
}
[data-testid="stSidebar"] [class*="st-key-nav_"] button [data-testid="stIconMaterial"] { color: #6B778A; font-size: 1.25rem; }
[data-testid="stSidebar"] [class*="st-key-nav_"] button:hover { background: #EEF2F8; }
[data-testid="stSidebar"] [class*="st-key-nav_"] button:hover p { color: var(--navy); }
[data-testid="stSidebar"] [class*="st-key-nav_"] button[kind="primary"] { background: #E6EEF9; box-shadow: inset 3px 0 0 var(--biru); }
[data-testid="stSidebar"] [class*="st-key-nav_"] button[kind="primary"] p { color: var(--biru); font-weight: 700; }
[data-testid="stSidebar"] [class*="st-key-nav_"] button[kind="primary"] [data-testid="stIconMaterial"] { color: var(--biru); }
.label-menu { font-size: .68rem; font-weight: 700; letter-spacing: .09em; text-transform: uppercase;
              color: #8A94A6; margin: 6px 0 6px 4px; }
.merek { display:flex; align-items:center; gap:10px; margin: 0 0 14px; }
.merek .logo { background: var(--biru); color:#fff; border-radius:10px; width:36px; height:36px;
               display:flex; align-items:center; justify-content:center; font-size:1.1rem; }
.merek b { display:block; font-size:1rem; line-height:1.1; }
.merek span { font-size:.75rem; color: var(--redup); }

/* ===== kartu bergaris ===== */
[data-testid="stVerticalBlockBorderWrapper"] { background: var(--putih); border-radius: 14px; }
.kartu-judul { display: flex; justify-content: space-between; align-items: baseline;
               gap: 12px; margin-bottom: 6px; }
.kartu-judul h3 { font-size: 1rem !important; font-weight: 700; margin: 0; padding: 0 !important; }
.kartu-judul span { font-size: 0.8rem; color: var(--redup); }
.legenda { display: inline-flex; align-items: center; gap: 14px; }
.legenda i { display: inline-block; width: 10px; height: 10px; border-radius: 2px; margin-right: 6px; }

/* ===== judul produk (level 1) ===== */
.produk { display: flex; align-items: center; flex-wrap: wrap; gap: 12px; margin: 18px 0 14px; }
.produk h2 { font-size: 1.45rem !important; font-weight: 800; margin: 0; padding: 0 !important; }
.produk .meta { color: var(--redup); font-size: 0.9rem; }

/* ===== kartu utama: saran stok (level 1, satu-satunya yang besar) ===== */
.hero { background: var(--putih); border: 1px solid var(--garis); border-left: 6px solid var(--kuning);
        border-radius: 14px; padding: 22px 24px 18px; }
.hero .label { font-size: 0.9rem; font-weight: 600; color: var(--redup); }
.hero .angka { font-size: 3.8rem; font-weight: 800; line-height: 1.05; color: var(--navy);
               letter-spacing: -0.03em; font-variant-numeric: tabular-nums; margin-top: 4px; }
.hero .angka small { font-size: 1.15rem; font-weight: 600; color: var(--redup);
                     letter-spacing: 0; margin-left: 8px; }
.hero .nilai { font-size: 1.1rem; font-weight: 700; margin-top: 6px; }
.hero .periode { font-size: 0.82rem; color: var(--redup); margin-top: 2px; }
.rincian { display: grid; grid-template-columns: 1fr auto; row-gap: 6px; margin: 16px 0 0;
           padding-top: 12px; border-top: 1px solid var(--garis); font-size: 0.88rem; }
.rincian dt { color: var(--redup); }
.rincian dd { margin: 0; text-align: right; font-weight: 700; font-variant-numeric: tabular-nums; }

/* ===== angka pendamping (level 2, jelas lebih kecil dari hero) ===== */
.deret { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; }
.stat { background: var(--putih); border: 1px solid var(--garis); border-radius: 12px; padding: 14px 16px; }
.stat .label { font-size: 0.8rem; color: var(--redup); font-weight: 600; }
.stat .nilai { font-size: 1.35rem; font-weight: 800; margin-top: 2px; font-variant-numeric: tabular-nums; }
.stat .nilai small { font-size: 0.82rem; font-weight: 600; color: var(--redup); margin-left: 4px; }
.stat .sub { font-size: 0.78rem; color: var(--redup); margin-top: 2px; }
.stat .sub b { color: var(--biru); }

/* ===== label klaster: tebal = prioritas tinggi ===== */
.pil { display: inline-block; padding: 3px 11px; border-radius: 999px; font-size: 0.78rem; font-weight: 700; }
.pil.fast { background: var(--biru); color: #fff; }
.pil.medium { background: #DCE7F6; color: var(--biru); }
.pil.slow { background: #EAEEF3; color: var(--redup); }

/* ===== tabel HTML (angka rata kanan, huruf sama dengan halaman) ===== */
.tabel { overflow: auto; border-radius: 10px; }
.tabel table { width: 100%; border-collapse: collapse; font-size: 0.88rem; font-variant-numeric: tabular-nums; }
.tabel th { position: sticky; top: 0; background: #F7F9FC; color: var(--redup); font-weight: 600;
            font-size: 0.8rem; text-align: right; padding: 10px 14px; border-bottom: 1px solid var(--garis); }
.tabel td { text-align: right; padding: 9px 14px; border-bottom: 1px solid #EEF2F7; }
.tabel th:first-child, .tabel td:first-child { text-align: left; }
.tabel tr.pertama td { background: #FFF8E1; font-weight: 700; }
.tabel td.tebal { font-weight: 700; }
.batang { display: flex; align-items: center; justify-content: flex-end; gap: 10px; }
.batang i { display: block; height: 8px; border-radius: 4px; background: var(--biru-muda); }

/* ===== kartu klaster ===== */
.klaster { background: var(--putih); border: 1px solid var(--garis); border-radius: 14px;
           padding: 18px 20px; border-top: 5px solid var(--abu, #B4BDCB); height: 100%; }
.klaster.fast { --abu: var(--biru); } .klaster.medium { --abu: var(--biru-muda); }
.klaster .nama { font-size: 0.95rem; font-weight: 700; }
.klaster .jumlah { font-size: 2.4rem; font-weight: 800; line-height: 1.1; margin-top: 4px; letter-spacing: -0.02em; }
.klaster .jumlah small { font-size: 0.95rem; font-weight: 600; color: var(--redup); margin-left: 6px; letter-spacing: 0; }
.klaster .rata { font-size: 0.82rem; color: var(--redup); margin-top: 4px; }
.klaster .peran { font-size: 0.88rem; margin-top: 10px; padding-top: 10px; border-top: 1px solid var(--garis); }

.catatan { font-size: 0.8rem; color: var(--redup); margin-top: 8px; }
.kaki { font-size: 0.8rem; color: var(--redup); margin-top: 28px; padding-top: 14px; border-top: 1px solid var(--garis); }
</style>
""", unsafe_allow_html=True)


def tema_grafik(chart):
    return (chart.configure_view(strokeWidth=0)
            .configure_axis(labelFont=FONT, titleFont=FONT, labelColor=ABU_TUA, titleColor=ABU_TUA,
                            labelFontSize=11, titleFontSize=11, domain=False, tickColor="#DCE3EE",
                            gridColor="#E9EDF3")
            .configure_legend(labelFont=FONT, titleFont=FONT, labelColor=ABU_TUA))


# ---------------- data ----------------
riwayat_semua, produk, tanggal_data_akhir = muat_data()
klaster = muat_klaster()
klaster_produk = klaster.set_index("produk")["klaster"].to_dict()
if "tambahan" not in st.session_state:
    st.session_state.tambahan = {}

# ---------------- panel kiri: pengaturan yang berlaku untuk seluruh halaman ----------------
produk_aktif = st.session_state.get("produk_dipilih", produk.index[0])
HALAMAN = ["Prediksi", "Rencana restock", "Klaster produk", "Data dan model"]
IKON = {"Prediksi": ":material/monitoring:", "Rencana restock": ":material/inventory_2:",
        "Klaster produk": ":material/bubble_chart:", "Data dan model": ":material/database:"}
with st.sidebar:
    tulis_html('<div class="merek"><div class="logo">📊</div><div><b>Minion Mart</b><span>Prediksi permintaan</span></div></div>')
    if "halaman" not in st.session_state:
        st.session_state.halaman = HALAMAN[0]
    tulis_html('<div class="label-menu">Menu</div>')
    for i, nama_h in enumerate(HALAMAN):
        aktif = st.session_state.halaman == nama_h
        if st.button(nama_h, key=f"nav_{i}", icon=IKON[nama_h], type="primary" if aktif else "tertiary", width="stretch"):
            st.session_state.halaman = nama_h
            st.rerun()
    halaman = st.session_state.halaman
    st.divider()
    tulis_html('<div class="label-menu">Pengaturan</div>')
    label_aman = st.segmented_control(
        "Peluang stok cukup", list(TINGKAT_AMAN), default="90%", key="aman",
        help="Makin tinggi, makin besar cadangan stok. Pada 90%, dari 10 hari kira-kira 9 hari stok cukup menutup penjualan.") or "90%"
    z = TINGKAT_AMAN[label_aman]

    st.divider()
    tulis_html('<div class="label-menu">Catat penjualan terbaru</div>')
    st.caption(f"Untuk produk {produk_aktif}")
    nilai = st.number_input("Jumlah terjual hari berikutnya", min_value=0.0, step=1.0)
    t1, t2 = st.columns(2)
    if t1.button("Tambahkan", type="primary", width="stretch"):
        st.session_state.tambahan.setdefault(produk_aktif, []).append(nilai)
        st.rerun()
    if t2.button("Reset", width="stretch"):
        st.session_state.tambahan.pop(produk_aktif, None)
        st.rerun()
    st.caption("Angka tambahan hanya berlaku selama halaman terbuka.")

# ---------------- level 0: kepala halaman ----------------
tulis_html(f"""
<div class="kepala">
  <div>
    <h1>Prediksi Permintaan Harian Minion Mart</h1>
    <p>Perkiraan penjualan harian dan stok yang perlu disiapkan. Model prediksi per produk tersedia untuk {len(produk)} produk yang terjual hampir tiap hari; produk lain (termasuk yang masuk klaster Laris) memakai aturan klaster di menu Rencana restock.</p>
  </div>
  <div class="data">Data penjualan sampai {tanggal_indo(tanggal_data_akhir)}</div>
</div>
""")

st.markdown("""<style>
.langkah {display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin:10px 0 14px;}
.langkah div {background:#fff; border:1px solid var(--garis); border-radius:12px; padding:10px 14px; font-size:.86rem; color:var(--navy);}
.langkah b {color:var(--biru);}
</style>""", unsafe_allow_html=True)
tulis_html("""
<div class="langkah">
  <div><b>1. Lihat perkiraan.</b> Menu Prediksi (panel kiri) menunjukkan perkiraan semua produk. Klik satu baris untuk melihat detailnya.</div>
  <div><b>2. Isi stok sekarang.</b> Menu Rencana restock: ketik stok yang ada di toko untuk tiap produk.</div>
  <div><b>3. Ikuti daftar.</b> Produk berstatus Segera restock dipesan lebih dulu; jumlah pesanan sudah dihitung.</div>
</div>
""")


# =====================================================================
# TAB 1: tabel semua produk, lalu detail produk yang dipilih (jawaban > bukti > rincian)
# =====================================================================
if halaman == "Prediksi":
    # -- perkiraan semua produk untuk lama stok yang dipilih
    lama_stok = st.session_state.get("lama") or 7  # None bila pilihan dibatalkan
    data_p = []
    for p in produk.index:
        r = riwayat_semua[p] + st.session_state.tambahan.get(p, [])
        pr = prediksi_ke_depan(r, lama_stok)
        sd, _, _ = saran_stok(pr, float(produk.loc[p, "rmse"]), z)
        r7, r21 = sum(r[-7:]) / 7, sum(r[-21:]) / 21
        h = float(produk.loc[p, "harga_satuan"])
        data_p.append({"Produk": p, "Klaster": TAMPIL.get(klaster_produk.get(p), "-"),
                       "Perkiraan hari berikut (unit)": pr[0], "Tren 7 hari (%)": (r7 - r21) / r21 * 100 if r21 else 0.0,
                       "Stok disiapkan (unit)": sd, "Nilai stok (Rp)": sd * h})
    df_p = pd.DataFrame(data_p).sort_values("Perkiraan hari berikut (unit)", ascending=False).reset_index(drop=True)

    tulis_html(f"""
    <div class="deret" style="grid-template-columns:repeat(3,1fr)">
      <div class="stat"><div class="label">Total stok disiapkan ({lama_stok} hari)</div>
        <div class="nilai">{angka(df_p["Stok disiapkan (unit)"].sum(), 0)}<small>unit</small></div></div>
      <div class="stat"><div class="label">Perkiraan nilai stok</div>
        <div class="nilai">{rupiah(df_p["Nilai stok (Rp)"].sum())}</div></div>
      <div class="stat"><div class="label">Produk dipantau</div>
        <div class="nilai">{len(df_p)}<small>produk bermodel</small></div></div>
    </div>
    <div style="height:12px"></div>
    """)

    with st.container(border=True):
        h1, h2 = st.columns([3, 2], vertical_alignment="center")
        with h1:
            tulis_html(judul_kartu("Perkiraan semua produk", "klik baris untuk melihat detail"))
        lama_stok = h2.segmented_control("Stok untuk", PILIHAN_HARI, default=7, key="lama",
                                         format_func=lambda n: f"{n} hari") or 7
        acara = st.dataframe(
            df_p, hide_index=True, width="stretch", height=300, on_select="rerun",
            selection_mode="single-row", key="tabel_prediksi",
            column_config={
                "Perkiraan hari berikut (unit)": st.column_config.NumberColumn(format="%.1f"),
                "Tren 7 hari (%)": st.column_config.NumberColumn(
                    format="%+.0f", help="Rata-rata penjualan 7 hari terakhir dibanding 21 hari terakhir."),
                "Stok disiapkan (unit)": st.column_config.NumberColumn(format="%d"),
                "Nilai stok (Rp)": st.column_config.NumberColumn(format="%d")})
        dipilih = acara.selection.rows
        nama = df_p.loc[dipilih[0], "Produk"] if dipilih else df_p.loc[0, "Produk"]
        st.session_state["produk_dipilih"] = nama

    # -- hitung
    tambahan = st.session_state.tambahan.get(nama, [])
    riwayat = riwayat_semua[nama] + tambahan
    tanggal_terakhir = tanggal_data_akhir + timedelta(days=len(tambahan))
    tanggal_berikut = tanggal_terakhir + timedelta(days=1)
    rmse = float(produk.loc[nama, "rmse"])
    harga = float(produk.loc[nama, "harga_satuan"])
    pred = prediksi_ke_depan(riwayat, 14)
    butuh, total, cadangan = saran_stok(pred[:lama_stok], rmse, z)
    rata7, rata21 = sum(riwayat[-7:]) / 7, sum(riwayat[-21:]) / 21
    selisih = (rata7 - rata21) / rata21 * 100 if rata21 else 0
    tgl_pred = [tanggal_berikut + timedelta(days=i) for i in range(lama_stok)]
    nama_klaster = klaster_produk.get(nama, "-")

    # -- level 1: nama produk
    tulis_html(f"""
    <div class="produk">
      <h2>{escape(nama)}</h2>
      {pil(nama_klaster)}
      <span class="meta">Harga satuan {rupiah(harga)}</span>
    </div>
    """)

    # -- level 1 dan 2: jawaban (kiri, sempit) dan bukti (kanan, lebar)
    kiri, kanan = st.columns([4, 8], gap="large")

    with kiri:
        panah = "▲" if selisih >= 0 else "▼"
        arah = "naik" if selisih >= 0 else "turun"
        tulis_html(f"""
        <div class="hero">
          <div class="label">Stok yang perlu disiapkan untuk {lama_stok} hari</div>
          <div class="angka">{angka(butuh, 0)}<small>unit</small></div>
          <div class="nilai">Senilai {rupiah(butuh * harga)}</div>
          <div class="periode">{tanggal_pendek(tgl_pred[0])} sampai {tanggal_pendek(tgl_pred[-1])}</div>
          <dl class="rincian">
            <dt>Perkiraan permintaan</dt><dd>{angka(total)} unit</dd>
            <dt>Cadangan pengaman <span title="Tambahan stok untuk berjaga-jaga jika penjualan lebih tinggi dari perkiraan">(?)</span></dt><dd>+ {angka(cadangan)} unit</dd>
          </dl>
        </div>
        <div style="height:12px"></div>
        <div class="deret">
          <div class="stat">
            <div class="label">Perkiraan {tanggal_pendek(tgl_pred[0])}</div>
            <div class="nilai">{angka(pred[0])}<small>unit</small></div>
          </div>
          <div class="stat">
            <div class="label">Rata-rata 7 hari</div>
            <div class="nilai">{angka(rata7)}<small>unit</small></div>
            <div class="sub"><b>{panah} {angka(abs(selisih))}%</b> {arah} dari rata-rata 21 hari</div>
          </div>
        </div>
        """)

    with kanan:
        with st.container(border=True):
            tulis_html(judul_kartu(
                "Penjualan 28 hari terakhir dan perkiraan",
                f'<span class="legenda"><span><i style="background:{ABU}"></i>Aktual</span>'
                f'<span><i style="background:{BIRU}"></i>Perkiraan</span></span>'))
            aktual = riwayat[-28:]
            tgl_aktual = [tanggal_terakhir - timedelta(days=len(aktual) - 1 - i) for i in range(len(aktual))]
            df = pd.DataFrame({
                "Tanggal": tgl_aktual + tgl_pred,
                "Jumlah": [round(v, 1) for v in aktual + pred[:lama_stok]],
                "Jenis": ["Aktual"] * len(aktual) + ["Perkiraan"] * lama_stok,
            })
            df_rentang = pd.DataFrame({
                "Tanggal": tgl_pred,
                "Bawah": [round(max(0, p - rmse), 1) for p in pred[:lama_stok]],
                "Atas": [round(p + rmse, 1) for p in pred[:lama_stok]],
            })
            sumbu_x = alt.X("Tanggal:T", timeUnit="yearmonthdate", title=None,
                            axis=alt.Axis(format="%d %b", labelAngle=0, grid=False,
                                          tickCount={"interval": "day", "step": 4}))
            batang = (alt.Chart(df).mark_bar(cornerRadiusTopLeft=2, cornerRadiusTopRight=2)
                      .encode(x=sumbu_x, y=alt.Y("Jumlah:Q", title=None),
                              color=alt.Color("Jenis:N", legend=None,
                                              scale=alt.Scale(domain=["Aktual", "Perkiraan"], range=[ABU, BIRU])),
                              tooltip=[alt.Tooltip("Tanggal:T", format="%d %b %Y"), "Jumlah", "Jenis"]))
            rentang = (alt.Chart(df_rentang).mark_rule(color=NAVY, strokeWidth=1.2, opacity=0.6)
                       .encode(x=sumbu_x, y="Bawah:Q", y2="Atas:Q"))
            st.altair_chart(tema_grafik((batang + rentang).properties(height=320)), theme=None, width="stretch")
            st.markdown(f'<div class="catatan">Garis tipis pada batang perkiraan menunjukkan perkiraan '
                        f'terendah dan tertinggi (± selisih rata-rata {angka(rmse, 2)} unit).</div>', unsafe_allow_html=True)

    # -- level 3: rincian. Kolom kiri = cara hitung, kolom kanan = tabel (grid sama dengan baris atas)
    st.markdown('<div style="height:6px"></div>', unsafe_allow_html=True)
    kiri2, kanan2 = st.columns([4, 8], gap="large")

    with kiri2:
        with st.container(border=True):
            tulis_html(judul_kartu("Cara menghitung stok yang disiapkan"))
            tulis_html(f"""
            <dl class="rincian" style="border-top:0;margin-top:6px;padding-top:0">
              <dt>Total perkiraan {lama_stok} hari</dt><dd>{angka(total)}</dd>
              <dt>Faktor pengaman ({label_aman})</dt><dd>{z}</dd>
              <dt>Selisih perkiraan yang biasa terjadi (RMSE)</dt><dd>{angka(rmse, 2)}</dd>
              <dt>Faktor lama stok (akar {lama_stok})</dt><dd>{angka(math.sqrt(lama_stok), 2)}</dd>
              <dt>Cadangan pengaman</dt><dd>{angka(cadangan)}</dd>
              <dt>Total + cadangan</dt><dd>{angka(total + cadangan)}</dd>
              <dt>Dibulatkan ke atas</dt><dd>{angka(butuh, 0)} unit</dd>
            </dl>
            """)

    with kanan2:
        with st.container(border=True):
            tulis_html(judul_kartu("Perkiraan per hari", "unit"))
            baris = "".join(
                f'<tr class="{"pertama" if i == 0 else ""}"><td>{tanggal_indo(t)}</td>'
                f'<td>{angka(p)}</td><td>{angka(max(0, p - rmse))}</td><td>{angka(p + rmse)}</td></tr>'
                for i, (t, p) in enumerate(zip(tgl_pred, pred[:lama_stok])))
            tulis_html(f'<div class="tabel" style="max-height:420px"><table><thead><tr>'
                       f'<th>Tanggal</th><th>Perkiraan</th><th>Perkiraan terendah</th><th>Perkiraan tertinggi</th>'
                       f'</tr></thead><tbody>{baris}</tbody></table></div>')

# =====================================================================
# TAB RENCANA RESTOCK: stok saat ini > status > jumlah pesanan
# =====================================================================
# --- helper restock ---
HARI_DATA = 61  # jumlah hari data penjualan (1 Agustus - 30 September 2026)
klaster_idx = klaster.set_index("produk")
URUTAN_STATUS = ["Segera restock", "Perlu tambah", "Berlebih", "Aman", "Belum diisi"]
WARNA_STATUS = {"Segera restock": "background-color:#FDE2E2;color:#991B1B", "Perlu tambah": "background-color:#FEF3C7;color:#92400E",
                "Berlebih": "background-color:#E0E7FF;color:#3730A3", "Aman": "background-color:#DCFCE7;color:#166534",
                "Belum diisi": "background-color:#EEF1F6;color:#5B6778"}


def saran_aturan(total_unit, n, nama_klaster, z):
    """Produk tanpa model: perkiraan = rata-rata harian 61 hari x n. Cadangan = z x akar(perkiraan);
    produk kurang laku tanpa cadangan (minimal 1 unit) agar tidak menumpuk."""
    perk = total_unit / HARI_DATA * n
    cad = 0.0 if nama_klaster == "Slow-moving" else z * math.sqrt(perk)
    return max(1, math.ceil(perk + cad)), perk, cad


def status_stok(stok, perk, saran):
    if stok < perk:
        return "Segera restock"
    if stok < saran:
        return "Perlu tambah"
    if stok > 2 * saran:
        return "Berlebih"
    return "Aman"


def hitung_rencana(pilihan, stok_dict, n, z, riwayat_all, tambahan_all):
    baris = []
    for p in pilihan:
        if p in produk.index:
            r = riwayat_all[p] + tambahan_all.get(p, [])
            saran, perk, _ = saran_stok(prediksi_ke_depan(r, n), float(produk.loc[p, "rmse"]), z)
            metode = "Model prediksi"
        else:
            saran, perk, _ = saran_aturan(float(klaster_idx.loc[p, "total_unit"]), n,
                                          klaster_idx.loc[p, "klaster"], z)
            metode = "Aturan klaster"
        stok = stok_dict.get(p)
        if stok is None:
            status, cukup, pesan = "Belum diisi", None, None
        else:
            status = status_stok(stok, perk, saran)
            cukup = round(stok / (perk / n), 1) if perk > 0 else None
            pesan = max(0, saran - int(round(stok)))
        baris.append({"Status": status, "Produk": p, "Stok saat ini": stok, "Stok disiapkan": saran,
                      "Cukup untuk (hari)": cukup, "Perlu dipesan": pesan, "Metode": metode})
    df = pd.DataFrame(baris)
    if not df.empty:
        df["_u"] = df["Status"].map(URUTAN_STATUS.index)
        df["_c"] = df["Cukup untuk (hari)"].fillna(9999)
        df = df.sort_values(["_u", "_c"]).drop(columns=["_u", "_c"]).reset_index(drop=True)
    return df
# --- akhir helper ---

if halaman == "Rencana restock":
    with st.container(border=True):
        s1, s2 = st.columns([4, 3], gap="large", vertical_alignment="bottom")
        skala = s1.segmented_control("Tampilkan produk", ["Semua"] + URUTAN_KLASTER, default="Fast-moving",
                                     key="skala_restock", format_func=lambda x: TAMPIL.get(x, x)) or "Fast-moving"
        n_hari = s2.segmented_control("Stok untuk", PILIHAN_HARI, default=7, key="lama_restock",
                                      format_func=lambda n: f"{n} hari") or 7

    sumber = klaster if skala == "Semua" else klaster[klaster["klaster"] == skala]
    pilihan = sumber.sort_values("total_unit", ascending=False)["produk"].tolist()
    stok_dict = st.session_state.setdefault("stok_input", {})

    kiri_r, kanan_r = st.columns([4, 8], gap="large")
    with kiri_r:
        with st.container(border=True):
            tulis_html(judul_kartu("1. Isi stok saat ini", f"{len(pilihan)} produk"))
            df_in = pd.DataFrame({"Produk": pilihan,
                                  "Stok saat ini": [stok_dict.get(p, float("nan")) for p in pilihan]})
            edit = st.data_editor(df_in, hide_index=True, width="stretch", height=460, disabled=["Produk"],
                                  key=f"editor_stok_{hash(tuple(pilihan))}",
                                  column_config={"Stok saat ini": st.column_config.NumberColumn(
                                      "Stok saat ini (unit)", min_value=0, step=1, format="%d")})
    for p, v in zip(edit["Produk"], edit["Stok saat ini"]):
        if pd.notna(v):
            stok_dict[p] = float(v)
        else:
            stok_dict.pop(p, None)

    with kanan_r:
        if not stok_dict:
            st.info("Isi stok pada tabel di kiri. Produk yang perlu dipesan akan muncul di sini.")
        else:
            rencana = hitung_rencana(list(stok_dict), stok_dict, n_hari, z, riwayat_semua, st.session_state.tambahan)
            jumlah = rencana["Status"].value_counts()
            perlu = rencana[rencana["Status"].isin(["Segera restock", "Perlu tambah"])]
            tulis_html(f"""
            <div class="deret" style="grid-template-columns:repeat(4,1fr)">
              <div class="stat"><div class="label">Segera restock</div><div class="nilai">{int(jumlah.get("Segera restock", 0))}<small>produk</small></div></div>
              <div class="stat"><div class="label">Perlu tambah</div><div class="nilai">{int(jumlah.get("Perlu tambah", 0))}<small>produk</small></div></div>
              <div class="stat"><div class="label">Berlebih</div><div class="nilai">{int(jumlah.get("Berlebih", 0))}<small>produk</small></div></div>
              <div class="stat"><div class="label">Total perlu dipesan</div><div class="nilai">{angka(rencana["Perlu dipesan"].fillna(0).sum(), 0)}<small>unit</small></div></div>
            </div>
            <div style="height:12px"></div>
            """)
            with st.container(border=True):
                tulis_html(judul_kartu("2. Perlu direstok sekarang", f"{len(perlu)} dari {len(rencana)} produk yang diisi"))
                if perlu.empty:
                    st.write("Tidak ada produk yang perlu direstok dari stok yang sudah diisi.")
                else:
                    tampil_r = perlu[["Status", "Produk", "Stok saat ini", "Perlu dipesan", "Cukup untuk (hari)"]]
                    sty = tampil_r.style
                    sty = (sty.map if hasattr(sty, "map") else sty.applymap)(
                        lambda v: WARNA_STATUS.get(v, ""), subset=["Status"])
                    st.dataframe(sty, hide_index=True, width="stretch", height=340, column_config={
                        "Status": st.column_config.TextColumn(
                            "Status", help="Segera restock: stok kurang dari perkiraan penjualan. "
                                           "Perlu tambah: stok cukup tetapi belum mencapai stok yang disiapkan."),
                        "Stok saat ini": st.column_config.NumberColumn(format="%d"),
                        "Perlu dipesan": st.column_config.NumberColumn(format="%d"),
                        "Cukup untuk (hari)": st.column_config.NumberColumn(format="%.1f")})
                st.download_button("Unduh semua hasil (CSV)", rencana.to_csv(index=False).encode("utf-8-sig"),
                                   file_name=f"rencana_restock_{n_hari}hari.csv", mime="text/csv")

# =====================================================================
# TAB 3: klaster. Urutan baca: ringkasan 3 klaster > sebaran > daftar
# =====================================================================
if halaman == "Klaster produk":
    ringkas = (klaster.groupby("klaster")
               .agg(jumlah=("produk", "size"), unit=("total_unit", "mean"), hari=("hari_terjual", "mean"))
               .reindex(URUTAN_KLASTER))
    kolom = st.columns(3, gap="medium")
    for kol, (nm, r) in zip(kolom, ringkas.iterrows()):
        with kol:
            tulis_html(f"""
            <div class="klaster {GAYA_KLASTER[nm]}">
              <div class="nama">{TAMPIL[nm]} ({nm})</div>
              <div class="jumlah">{int(r.jumlah)}<small>produk ({r.jumlah / len(klaster) * 100:.0f}%)</small></div>
              <div class="rata">Rata-rata {angka(r.unit)} unit dalam {angka(r.hari)} hari terjual</div>
              <div class="peran">{PERAN_KLASTER[nm]}</div>
            </div>
            """)

    st.markdown('<div style="height:6px"></div>', unsafe_allow_html=True)
    kiri3, kanan3 = st.columns([6, 6], gap="large")

    with kiri3:
        with st.container(border=True):
            tulis_html(judul_kartu(
                "Sebaran produk",
                '<span class="legenda">' + "".join(
                    f'<span><i style="background:{w};border-radius:50%"></i>{TAMPIL[n]}</span>'
                    for n, w in zip(URUTAN_KLASTER, WARNA_KLASTER)) + '</span>'))
            sebar = klaster[klaster["total_unit"] > 0].copy()
            titik = (alt.Chart(sebar).mark_circle(size=48, opacity=0.6)
                     .encode(x=alt.X("hari_terjual:Q", title="Hari terjual (dari 61 hari)",
                                     scale=alt.Scale(type="log", domain=[1, 64]),
                                     axis=alt.Axis(values=[1, 2, 5, 10, 20, 40, 60], format="d", grid=False)),
                             y=alt.Y("total_unit:Q", title="Total unit",
                                     scale=alt.Scale(type="log", domain=[1, 1200]),
                                     axis=alt.Axis(values=[1, 2, 5, 10, 20, 50, 100, 200, 500, 1000], format="d")),
                             color=alt.Color("klaster:N", legend=None,
                                             scale=alt.Scale(domain=URUTAN_KLASTER, range=WARNA_KLASTER)),
                             tooltip=[alt.Tooltip("produk:N", title="Produk"),
                                      alt.Tooltip("total_unit:Q", title="Total unit"),
                                      alt.Tooltip("hari_terjual:Q", title="Hari terjual"),
                                      alt.Tooltip("klaster:N", title="Klaster")])
                     .properties(height=440))
            st.altair_chart(tema_grafik(titik), theme=None, width="stretch")
            st.markdown('<div class="catatan">Tiap titik satu produk. Makin ke kanan atas, makin cepat laku.</div>',
                        unsafe_allow_html=True)

    with kanan3:
        with st.container(border=True):
            tulis_html(judul_kartu("Daftar produk", f"{len(klaster)} produk"))
            cari = st.text_input("Cari produk", placeholder="Ketik nama produk")
            pilih = st.segmented_control("Klaster", ["Semua"] + URUTAN_KLASTER, default="Semua",
                                         key="filter_klaster", format_func=lambda x: TAMPIL.get(x, x)) or "Semua"
            daftar = klaster if pilih == "Semua" else klaster[klaster["klaster"] == pilih]
            if cari.strip():
                daftar = daftar[daftar["produk"].str.contains(cari.strip(), case=False, regex=False)]
            daftar = (daftar.assign(klaster=daftar["klaster"].map(TAMPIL)).sort_values("total_unit", ascending=False)
                      .rename(columns={"produk": "Produk", "klaster": "Klaster",
                                       "total_unit": "Total unit", "hari_terjual": "Hari terjual"})
                      [["Produk", "Klaster", "Total unit", "Hari terjual"]])
            st.dataframe(daftar, hide_index=True, width="stretch", height=290,
                         column_config={"Total unit": st.column_config.NumberColumn(format="%d"),
                                        "Hari terjual": st.column_config.NumberColumn(format="%d")})

# =====================================================================
# TAB DATA DAN MODEL: kondisi data, statistik, dan bukti pemilihan model
# =====================================================================
@st.cache_data
def muat_analisis():
    harian = pd.read_csv(FOLDER / "ringkasan_harian.csv", parse_dates=["tanggal"])
    top = pd.read_csv(FOLDER / "top_nilai.csv", dtype={"produk": str})
    model = pd.read_csv(FOLDER / "perbandingan_model.csv")
    return harian, top, model


def hitung_uji(riwayat_all, tgl_akhir, n_uji=14):
    """Total aktual dan total prediksi rata-rata bergerak 21 hari (satu hari ke depan) pada data uji."""
    akt, prd = [0.0] * n_uji, [0.0] * n_uji
    for r in riwayat_all.values():
        for i, t in enumerate(range(len(r) - n_uji, len(r))):
            akt[i] += r[t]
            prd[i] += sum(r[t - JENDELA:t]) / JENDELA
    tgl = [tgl_akhir - timedelta(days=n_uji - 1 - i) for i in range(n_uji)]
    return pd.DataFrame({"Tanggal": tgl * 2, "Jenis": ["Aktual"] * n_uji + ["Prediksi"] * n_uji, "Unit": akt + prd})


def statistik_produk(riwayat_all, n=10):
    baris = []
    for p, r in riwayat_all.items():
        s_ = pd.Series(r, dtype=float)
        baris.append({"Produk": p, "Rata-rata": s_.mean(), "Simpangan baku": s_.std(), "Min": int(s_.min()),
                      "Maks": int(s_.max()), "Hari tanpa penjualan (%)": (s_ == 0).mean() * 100})
    return pd.DataFrame(baris).sort_values("Rata-rata", ascending=False).head(n).reset_index(drop=True)


if halaman == "Data dan model":
    harian, top_nilai, model_df = muat_analisis()
    harian["juta"] = harian["total_rp"] / 1e6
    harian["Hari"] = harian["tanggal"].dt.weekday.map(lambda i: NAMA_HARI[i])
    n_prod = len(klaster)
    satu_hari = int((klaster["hari_terjual"] == 1).sum())
    maks5 = int((klaster["hari_terjual"] <= 5).sum())

    tulis_html(f"""
    <div class="deret" style="grid-template-columns:repeat(4,1fr)">
      <div class="stat"><div class="label">Total penjualan (61 hari)</div><div class="nilai">{rupiah(harian["total_rp"].sum())}</div></div>
      <div class="stat"><div class="label">Rata-rata per hari</div><div class="nilai">{rupiah(harian["total_rp"].mean())}</div></div>
      <div class="stat"><div class="label">Produk tercatat</div><div class="nilai">{angka(n_prod, 0)}<small>{satu_hari} terjual 1 hari saja</small></div></div>
      <div class="stat"><div class="label">Produk bermodel</div><div class="nilai">{len(produk)}<small>terjual min. 45 hari</small></div></div>
    </div>
    <div style="height:12px"></div>
    """)

    d1, d2 = st.columns([7, 5], gap="medium")
    with d1.container(border=True):
        tulis_html(judul_kartu("Total penjualan harian", "juta rupiah, 1 Agustus - 30 September 2026"))
        dasar = alt.Chart(harian).encode(x=alt.X("tanggal:T", title=None, axis=alt.Axis(format="%d %b", grid=False)))
        garis = dasar.mark_line(color=BIRU, strokeWidth=2, point=alt.OverlayMarkDef(size=22, color=BIRU)).encode(
            y=alt.Y("juta:Q", title=None, scale=alt.Scale(zero=True)),
            tooltip=[alt.Tooltip("tanggal:T", format="%d %b %Y", title="Tanggal"),
                     alt.Tooltip("juta:Q", format=".2f", title="Juta Rp")])
        rata = alt.Chart(pd.DataFrame({"y": [harian["juta"].mean()]})).mark_rule(
            color=ABU_TUA, strokeDash=[4, 4]).encode(y="y:Q")
        st.altair_chart(tema_grafik((garis + rata).properties(height=260)), theme=None, width="stretch")
        st.markdown('<div class="catatan">Garis putus-putus = rata-rata harian. Titik terendah (8 Agustus) dipengaruhi struk '
                    'yang terpotong, bukan penurunan penjualan sebenarnya.</div>', unsafe_allow_html=True)
    with d2.container(border=True):
        tulis_html(judul_kartu("Rata-rata menurut hari", "juta rupiah"))
        per_hari = harian.groupby("Hari", as_index=False)["juta"].mean()
        tertinggi = per_hari["juta"].max()
        st.altair_chart(tema_grafik(
            alt.Chart(per_hari).mark_bar(cornerRadiusTopLeft=2, cornerRadiusTopRight=2).encode(
                x=alt.X("Hari:N", sort=NAMA_HARI, title=None, axis=alt.Axis(labelAngle=0)),
                y=alt.Y("juta:Q", title=None),
                color=alt.condition(alt.datum.juta >= tertinggi, alt.value(BIRU), alt.value(ABU)),
                tooltip=[alt.Tooltip("Hari:N"), alt.Tooltip("juta:Q", format=".2f", title="Juta Rp")]
            ).properties(height=260)), theme=None, width="stretch")
        st.markdown('<div class="catatan">Selisih antarhari tidak besar; Jumat tertinggi dan Senin terendah.</div>',
                    unsafe_allow_html=True)

    d3, d4 = st.columns([5, 7], gap="medium")
    with d3.container(border=True):
        tulis_html(judul_kartu("10 produk nilai penjualan terbesar", "juta rupiah"))
        tn = top_nilai.assign(juta=top_nilai["total_rp"] / 1e6)
        st.altair_chart(tema_grafik(
            alt.Chart(tn).mark_bar(color=BIRU, cornerRadiusTopRight=2, cornerRadiusBottomRight=2).encode(
                y=alt.Y("produk:N", sort="-x", title=None),
                x=alt.X("juta:Q", title=None),
                tooltip=[alt.Tooltip("produk:N", title="Produk"), alt.Tooltip("juta:Q", format=".2f", title="Juta Rp"),
                         alt.Tooltip("total_unit:Q", format=",.0f", title="Total unit")]
            ).properties(height=300)), theme=None, width="stretch")
    with d4.container(border=True):
        tulis_html(judul_kartu("Distribusi hari terjual per produk", f"{angka(n_prod, 0)} produk"))
        batas = [0, 1, 5, 14, 44, 61]
        label = ["1 hari", "2-5 hari", "6-14 hari", "15-44 hari", "45-61 hari"]
        sebaran_h = pd.cut(klaster["hari_terjual"], bins=batas, labels=label).value_counts().reindex(label).reset_index()
        sebaran_h.columns = ["Kelompok", "Produk"]
        sebaran_h["Bermodel"] = sebaran_h["Kelompok"] == "45-61 hari"
        grafik_h = alt.Chart(sebaran_h).encode(
            x=alt.X("Kelompok:N", sort=label, title=None, axis=alt.Axis(labelAngle=0)),
            y=alt.Y("Produk:Q", title=None))
        batang_h = grafik_h.mark_bar(cornerRadiusTopLeft=2, cornerRadiusTopRight=2).encode(
            color=alt.condition(alt.datum.Bermodel, alt.value(BIRU), alt.value(ABU)),
            tooltip=[alt.Tooltip("Kelompok:N"), alt.Tooltip("Produk:Q")])
        angka_h = grafik_h.mark_text(dy=-8, color=NAVY, fontSize=12).encode(text="Produk:Q")
        st.altair_chart(tema_grafik((batang_h + angka_h).properties(height=300)), theme=None, width="stretch")
        st.markdown(f'<div class="catatan">{angka(maks5, 0)} dari {angka(n_prod, 0)} produk terjual paling banyak lima hari. '
                    'Hanya kelompok biru (45-61 hari) yang cukup rutin untuk dimodelkan.</div>', unsafe_allow_html=True)

    d5, d6 = st.columns([5, 7], gap="medium")
    with d5.container(border=True):
        tulis_html(judul_kartu("Perbandingan 12 model", "MAE data uji 17-30 September, makin kecil makin baik"))
        md = model_df.assign(terpilih=model_df["model"] == "Rata-rata bergerak 21 hari")
        urut_model = md["model"].tolist()
        dasar_m = alt.Chart(md).encode(y=alt.Y("model:N", sort=urut_model, title=None),
                                       x=alt.X("mae:Q", title=None, scale=alt.Scale(domain=[0, 3.4])))
        batang_m = dasar_m.mark_bar(cornerRadiusTopRight=2, cornerRadiusBottomRight=2).encode(
            color=alt.condition(alt.datum.terpilih, alt.value(BIRU), alt.value(ABU)),
            tooltip=[alt.Tooltip("model:N", title="Model"), alt.Tooltip("mae:Q", format=".3f", title="MAE"),
                     alt.Tooltip("rmse:Q", format=".3f", title="RMSE"), alt.Tooltip("wape:Q", format=".1f", title="WAPE (%)")])
        label_m = dasar_m.mark_text(align="left", dx=4, color=NAVY, fontSize=11).encode(text=alt.Text("mae:Q", format=".3f"))
        st.altair_chart(tema_grafik((batang_m + label_m).properties(height=340)), theme=None, width="stretch")
        st.markdown('<div class="catatan">Biru = model terpilih. Model pembelajaran mesin tidak mengungguli rata-rata bergerak '
                    'karena data hanya 61 hari.</div>', unsafe_allow_html=True)
    with d6.container(border=True):
        tulis_html(judul_kartu("Aktual dan prediksi pada data uji", f"total {len(produk)} produk, unit per hari"))
        uji = hitung_uji(riwayat_semua, tanggal_data_akhir)
        st.altair_chart(tema_grafik(
            alt.Chart(uji).mark_line(strokeWidth=2.2, point=alt.OverlayMarkDef(size=26)).encode(
                x=alt.X("Tanggal:T", title=None, axis=alt.Axis(format="%d %b", grid=False)),
                y=alt.Y("Unit:Q", title=None, scale=alt.Scale(zero=False)),
                color=alt.Color("Jenis:N", scale=alt.Scale(domain=["Aktual", "Prediksi"], range=[BIRU, ABU]),
                                legend=alt.Legend(orient="top-left", direction="horizontal", title=None)),
                tooltip=[alt.Tooltip("Tanggal:T", format="%d %b %Y"), alt.Tooltip("Jenis:N"),
                         alt.Tooltip("Unit:Q", format=".1f")]
            ).properties(height=340)), theme=None, width="stretch")
        st.markdown('<div class="catatan">Prediksi mengikuti tingkat penjualan umum tetapi tidak menangkap lonjakan harian, '
                    'sehingga prediksi per hari perlu disertai cadangan stok.</div>', unsafe_allow_html=True)

    d7, d8 = st.columns([7, 5], gap="medium")
    with d7.container(border=True):
        tulis_html(judul_kartu("Statistik 10 produk dengan rata-rata tertinggi", "unit per hari"))
        st.dataframe(statistik_produk(riwayat_semua), hide_index=True, width="stretch", column_config={
            "Rata-rata": st.column_config.NumberColumn(format="%.1f"),
            "Simpangan baku": st.column_config.NumberColumn(format="%.1f"),
            "Hari tanpa penjualan (%)": st.column_config.NumberColumn(format="%.0f")})
    with d8.container(border=True):
        tulis_html(judul_kartu("Hasil evaluasi 12 model", "data uji 17-30 September 2026"))
        st.dataframe(model_df.rename(columns={"model": "Model", "mae": "MAE", "rmse": "RMSE", "wape": "WAPE (%)"}),
                     hide_index=True, width="stretch", column_config={
                         "MAE": st.column_config.NumberColumn(format="%.3f"),
                         "RMSE": st.column_config.NumberColumn(format="%.3f"),
                         "WAPE (%)": st.column_config.NumberColumn(format="%.1f")})

with st.expander("Catatan dan detail teknis"):
    validasi = pd.read_csv(FOLDER / "validasi_klaster.csv")
    sil3 = float(validasi.loc[validasi["k"] == 3, "silhouette"].iloc[0])
    sil2 = float(validasi.loc[validasi["k"] == 2, "silhouette"].iloc[0])
    st.markdown(
        "**Batasan**\n\n"
        "- Data penjualan hanya dua bulan (1 Agustus - 30 September 2026), sehingga pola musiman panjang belum terbaca.\n"
        f"- Hanya {len(produk)} produk (terjual minimal 45 dari 61 hari)  yang memakai model prediksi. "
        "Produk lain memakai aturan klaster berdasarkan rata-rata dua bulan.\n"
        "- Perkiraan belum memperhitungkan hari libur, promo, atau perubahan harga.\n"
        "- Data yang dipakai adalah penjualan, bukan permintaan sebenarnya. Saat stok habis, penjualan tercatat rendah padahal permintaan bisa lebih tinggi.\n"
        "- Stok saat ini diisi manual karena data stok tidak tersedia.\n"
        "- Data berakhir 30 September 2026. Catat penjualan terbaru (panel kiri) agar perkiraan lebih mutakhir.\n\n"
        "**Cara menghitung**\n\n"
        f"- Prediksi: rata-rata bergerak {JENDELA} hari; hari berikutnya memakai hasil prediksi sebelumnya.\n"
        "- Stok disiapkan = total perkiraan n hari + faktor pengaman × RMSE × akar n (faktor 1,28 untuk 90%, 1,64 untuk 95%).\n"
        "- RMSE memakai validasi bergulir: tiap hari dari hari ke-22 diprediksi dari data sebelumnya saja (40 prediksi per produk).\n"
        "- Produk tanpa model: perkiraan = total unit / 61 hari × n; cadangan = faktor pengaman × akar perkiraan; "
        "produk kurang laku tanpa cadangan dan minimal 1 unit.\n"
        "- Status stok: Segera restock bila stok kurang dari perkiraan; Perlu tambah bila kurang dari stok disiapkan; "
        "Berlebih bila lebih dari dua kali stok disiapkan; selain itu Aman.\n\n"
        "**Klaster**\n\n"
        f"- K-Means (k=3) pada total unit dan hari terjual (skala log, distandarkan), {len(klaster)} produk.\n"
        f"- Silhouette k=3 adalah {sil3:.3f}. k=2 sedikit lebih tinggi ({sil2:.3f}) tetapi hanya memisahkan laku dan tidak laku, "
        "sehingga k=3 dipilih sesuai proposal: laris, sedang, kurang laku.")
    st.dataframe(validasi.rename(columns={"k": "Jumlah klaster (k)", "silhouette": "Silhouette", "inertia": "Inertia"}),
                 hide_index=True, width="stretch")

tulis_html("""
<div class="kaki">Ketepatan pada uji 17-30 September 2026: perkiraan rata-rata meleset sekitar 2 unit per produk per hari (MAE 2,13; WAPE 52%).
Proyek Penambangan Data, Teknik Informatika UMRAH.</div>
""")
