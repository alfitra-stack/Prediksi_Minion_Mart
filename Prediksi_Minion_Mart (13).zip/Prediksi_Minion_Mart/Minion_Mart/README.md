# Prediksi Permintaan Harian Minion Mart

Jalankan:  pip install -r requirements.txt  lalu  python -m streamlit run app.py

- data_penjualan.csv : penjualan harian 36 produk bermodel (1 Agu - 30 Sep 2026)
- klaster.csv        : seluruh produk dari data bersih SiapMining_2401020038 (nama dirapikan, typo digabung; 1.524 produk), total unit, hari terjual, klaster
- produk.csv         : RMSE dan harga satuan produk bermodel
- Nama produk dibaca sebagai teks, sehingga produk bernama angka seperti "50" tetap terbaca.
- ringkasan_harian.csv : total penjualan toko (Rp, termasuk Rp baris yang dibuang saat pembersihan), unit dan jumlah baris data bersih per hari (tab Data dan model)
- top_nilai.csv        : 10 produk dengan nilai penjualan terbesar
- perbandingan_model.csv : hasil evaluasi 12 model pada data uji 17-30 September 2026
- validasi_klaster.csv : silhouette dan inertia untuk k=2 sampai 6
